import './App.css'
import Cards from './Components/Cards'

function App() {
  

  return (
    <>
     <Cards/>
    </>
  )
}

export default App
