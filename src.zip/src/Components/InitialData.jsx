import React from 'react';
import { Table, Thead, Tbody, Tr, Th, Td } from '@chakra-ui/react';
import "./InitialData.css";

const InitialData = () => {
  const firms = 5;
  const regions = 3;
  const products = 2;
  const channels = 2;

  const response = {};
  const result = {};

  for (let i = 0; i < firms; i++) {
    const fir = 'firm_' + (i + 1);
    response[fir] = {};
    result[fir] = {};

    for (let j = 0; j < regions; j++) {
      const joe = 'region' + (j + 1);
      response[fir][joe] = {};
      result[fir][joe] = {};

      for (let k = 0; k < products; k++) {
        const pr = 'product' + (k + 1);
        const data = [];
        const ans = [];

        

        for (let l = 0; l < channels; l++) {
          const temp = Math.floor(Math.random() * (20000 - 10000 + 1)) + 10000;
          
          const randomValue = (Math.random() * (2.00 - 0.50) + 0.50).toFixed(2);
          const percentageAmount = Math.floor((randomValue / 100) * temp);
          ans.push(percentageAmount+temp);
          data.push(temp);
        }

        response[fir][joe][pr] = data;
        result[fir][joe][pr] = ans;
      }
    }
  }

  console.log(result);

  const numberOfChannels = channels; // Assuming the number of channels is constant

  return (
    <div className="table-container">
      <table>
  <thead>
    <tr>
      <th>Firm</th>
      <th>Region</th>
      <th>Product</th>
      <th>Channel 1</th>
      <th>Channel 2</th>
    </tr>
  </thead>
  <tbody>
    {Object.keys(result).map((firm, firmIndex) => (
      Object.keys(result[firm]).map((region, regionIndex) => (
        Object.keys(result[firm][region]).map((product, productIndex) => (
          <tr key={`${firm}-${region}-${product}`}>
            {productIndex === 0 ? (
              <td className="firm-cell" rowSpan={Object.keys(result[firm]).length}>
                {firm}
              </td>
            ) : null}
            {regionIndex === 0 && productIndex === 0 ? (
              <td className="region-cell" rowSpan={Object.keys(result[firm][region]).length}>
                {region}
              </td>
            ) : null}
            <td className="product-cell">{product}</td>
            {result[firm][region][product].map((value, channelIndex) => (
              <td className="channel-cell" key={`value_${channelIndex}`}>
                {value}
              </td>
            ))}
          </tr>
        ))
      ))
    ))}
  </tbody>
</table>

    </div>
  );
};

export default InitialData;
