import json2xls from 'json2xls';
import fs from 'fs';
// Your JSON data
const jsonData = {
    "firm_1": {
        "region1": {
            "product1": [
                23532,
                23720
            ],
            "product2": [
                23532,
                24384
            ]
        },
        "region2": {
            "product1": [
                24463,
                24189
            ],
            "product2": [
                23799,
                24381
            ]
        },
        "region3": {
            "product1": [
                24187,
                24460
            ],
            "product2": [
                24410,
                23715
            ]
        }
    },
    "firm_2": {
        "region1": {
            "product1": [
                23525,
                23597
            ],
            "product2": [
                23643,
                24422
            ]
        },
        "region2": {
            "product1": [
                24379,
                23643
            ],
            "product2": [
                24264,
                23844
            ]
        },
        "region3": {
            "product1": [
                23535,
                23628
            ],
            "product2": [
                24441,
                23760
            ]
        }
    },
    "firm_3": {
        "region1": {
            "product1": [
                24432,
                24146
            ],
            "product2": [
                23777,
                24446
            ]
        },
        "region2": {
            "product1": [
                24182,
                24362
            ],
            "product2": [
                23650,
                24400
            ]
        },
        "region3": {
            "product1": [
                24158,
                24480
            ],
            "product2": [
                23585,
                24386
            ]
        }
    },
    "firm_4": {
        "region1": {
            "product1": [
                24309,
                24225
            ],
            "product2": [
                24350,
                23856
            ]
        },
        "region2": {
            "product1": [
                24283,
                24319
            ],
            "product2": [
                24129,
                24432
            ]
        },
        "region3": {
            "product1": [
                24206,
                24266
            ],
            "product2": [
                23717,
                23705
            ]
        }
    },
    "firm_5": {
        "region1": {
            "product1": [
                24338,
                23602
            ],
            "product2": [
                24268,
                23864
            ]
        },
        "region2": {
            "product1": [
                23616,
                24352
            ],
            "product2": [
                23705,
                23864
            ]
        },
        "region3": {
            "product1": [
                23801,
                23842
            ],
            "product2": [
                24369,
                23561
            ]
        }
    }
}

const xls = json2xls(jsonData);

// Save the Excel file
const excelFilePath = 'output.xlsx';
fs.writeFileSync(excelFilePath, xls, 'binary');

console.log(`Excel file saved as ${excelFilePath}`);