// import React from "react";
// import { Box, Button, Flex, Input, Text } from "@chakra-ui/react";
// import { useState } from "react";
// import Initial from "./Initial";

// const Cards = () => {
//   const [numberOfRegions, setNumberOfRegions] = useState("");
//   const [inputRegions, setInputRegions] = useState([]);
//   const [numberOfProducts, setNumberOfProducts] = useState("");
//   const [inputProducts, setInputProducts] = useState([]);

//   const [showIndustryBox, setShowIndustryBox] = useState(true);
//   const [showFirmBox, setShowFirmBox] = useState(false);
//   const [showRegionBox, setShowRegionBox] = useState(false);
//   const [showRegionInput, setShowRegionInput] = useState(false);
//   const [showProductBox, setShowProductBox] = useState(false);
//   const [showProductInput, setShowProductInput] = useState(false);
//   const [showTbale,setShowTable] = useState(false);

//   const [industryName, setIndustryName] = useState("");
//   const [firms, setFirms] = useState(0);
//   const [regionNames, setRegionNames] = useState([]);
//   const [productData, setProductData] = useState([]);

//   //console.log(productData[0]);

//   const handleRegionChange = (e) => {
//     setNumberOfRegions(e.target.value);
//   };

//   const handleRegionNameChange = (e, index) => {
//     const newName = e.target.value;
//     setRegionNames((prevRegionNames) => {
//       const updatedRegionNames = [...prevRegionNames];
//       updatedRegionNames[index] = newName;
//       console.log(updatedRegionNames); // Log the updated value
//       return updatedRegionNames; // Return the updated value
//     });
//   };

//   const handleProductDataChange = (e, index, field) => {
//     const newValue = e.target.value;

//     setProductData((prevProductData) => {
//       const updatedProductData = [...prevProductData];
//       updatedProductData[index] = {
//         ...updatedProductData[index],
//         [field]: newValue,
//       };
//       console.log(updatedProductData);
//       return updatedProductData;
//     });
//   };

//   console.log(productData);

//   const createRegionBoxes = () => {
//     const count = parseInt(numberOfRegions, 10);
//     if (!isNaN(count)) {
//       const newInputBoxes = Array.from({ length: count }, (_, index) => (
//         <Input
//           key={index}
//           type="text"
//           placeholder={`Enter Region ${index + 1}`}
//           value={regionNames[index]}
//           onChange={(e) => handleRegionNameChange(e, index)}
//           mb={2}
//         />
//       ));
//       setInputRegions(newInputBoxes);
//     }

//     setShowRegionBox(false);
//     setShowRegionInput(true);
//   };

//   const handleProductChange = (e) => {
//     setNumberOfProducts(e.target.value);
//   };

//   const createProductBoxes = () => {
//     const count = parseInt(numberOfProducts, 10);
//     if (!isNaN(count) && count >= 0) {
//       const newProductData = Array.from({ length: count }, () => ({
//         name: "",
//         units: "",
//         channels: "",
//       }));
//       setProductData(newProductData);

//       const newInputBoxes = newProductData.map((product, index) => (
//         <Box key={index} mb={10} w={"400px"}>
//           <Text>{`Product ${index + 1}`}</Text>
//           <Input
//             type="text"
//             placeholder={`Enter product ${index + 1} name`}
//             value={productData[index]?.name}
//             onChange={(e) => handleProductDataChange(e, index, "name")}
//             mb={2}
//           />
//           <Input
//             type="number"
//             placeholder={`Enter no. of units`}
//             value={productData[index]?.units}
//             onChange={(e) => handleProductDataChange(e, index, "units")}
//             mb={2}
//           />
//           <Input
//             type="number"
//             placeholder={`Enter no. of channels on product`}
//             value={productData[index]?.channels}
//             onChange={(e) => handleProductDataChange(e, index, "channels")}
//           />
//         </Box>
//       ));

//       setInputProducts(newInputBoxes);
//     }

//     setShowProductBox(false);
//     setShowProductInput(true);
//   };

//   const handleIndustryClick = () => {
//     setShowIndustryBox(false);
//     setShowFirmBox(true);
//   };

//   const handleFirmClick = () => {
//     setShowFirmBox(false);
//     setShowRegionBox(true);
//   };

//   const handleRegionInputClick = () => {
//     setShowRegionInput(false);
//     setShowProductBox(true);
//   };

//   const handleProductInputClick = () => {
//     setShowTable(true)
//   };

//   return (
//     <>
//     <Box textAlign="center" w={'900px'}  p="50px" mt={'80px'} border={'1px solid black'}>
//       {showIndustryBox && (
//         <Box p="10px">
//           <Text fontSize="lg">Enter Industry Name</Text>
//           <Input
//             type="text"
//             onChange={(e) => setIndustryName(e.target.value)}
//             placeholder="Enter industry name"
//           />
//           <Button mt="10px" onClick={handleIndustryClick}>
//             Next
//           </Button>
//         </Box>
//       )}

//       {showFirmBox && (
//         <Box p="10px">
//           <Text fontSize="lg">Enter Number of Firms</Text>
//           <Input
//             type="number"
//             onChange={(e) => setFirms(e.target.value)}
//             placeholder="Enter number of firms"
//           />
//           <Button mt="10px" onClick={handleFirmClick}>
//             Next
//           </Button>
//         </Box>
//       )}

//       {showRegionBox && (
//         <Box p="10px">
//           <Text fontSize="lg">Enter Number of Regions</Text>
//           <Input
//             type="number"
//             value={numberOfRegions}
//             onChange={handleRegionChange}
//             placeholder="Enter number of regions"
//           />
//           <Button mt="10px" onClick={createRegionBoxes}>
//             Next
//           </Button>
//         </Box>
//       )}

//       {showRegionInput && (
//         <Box p="10px">
//           {inputRegions}
//           <Button mt="10px" onClick={handleRegionInputClick}>
//             Next
//           </Button>
//         </Box>
//       )}

//       {showProductBox && (
//         <Box p="10px">
//           <Text fontSize="lg">Enter Number of Products</Text>
//           <Input
//             type="number"
//             value={numberOfProducts}
//             onChange={handleProductChange}
//             placeholder="Enter number of products"
//           />
//           <Button mt="10px" onClick={createProductBoxes}>
//             Next
//           </Button>
//         </Box>
//       )}

//       {showProductInput && (
//         <Box p="10px">
//           {inputProducts}
//           <Button mt="10px" onClick={handleProductInputClick}>
//             Submit
//           </Button>
//         </Box>
//       )}

//     </Box>
//     {/* {showTbale && (
//       <Initial numberOfProducts={numberOfProducts}/>
//     )} */}

//     </>
//   );
// };

// export default Cards;
import React, { useState } from "react";
import {
  Box,
  Button,
  Flex,
  FormControl,
  Heading,
  Input,
  Text,
} from "@chakra-ui/react";
import cookies from "js-cookie";
//import Initial from "./initial";
import InitialData from "./InitialData";

function Cards() {
  const [showTbale, setShowTable] = useState(false);
  // Step 2: Create a state to store form data

  const [formData, setFormData] = useState({
    industryName: "Onesmarter inc.",
    numOfFirms: 2,
    numOfRegions: 3,
    numOfProducts: 2,
    numOfChannels: 2,
  });

  // Step 3: Update the state as the user enters data
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Step 4: Handle form submission and save data to cookies
  const handleSubmit = () => {
    setShowTable(true);
    // Convert the form data to a JSON string
    const formDataJson = JSON.stringify(formData);
    // Save the data to cookies
    cookies.set(formDataJson);
    document.cookie = `formData=${formDataJson}`;
    // You can also add more cookie settings like expiration, path, etc.

    // Display a success message or perform any other action
    console.log(formData);
    alert("Data submitted and saved to cookies");
  };

  return (
    <>
      <Box mt={"20px"} border={"1px solid black"} p={10}>
        <Heading size={""} mb={"20px"}>
          Enter data
        </Heading>
        <FormControl>
          <Text textAlign={"left"}>Enter Industry Name</Text>
          <Input
            mb={"15px"}
            name="industryName" // Match the name to the state key
            value={formData.industryName} // Bind the input value to the state
            onChange={handleInputChange} // Call the update function on change
          ></Input>
          <Text textAlign={"left"}>Enter Number of firms</Text>
          <Input
            mb={"15px"}
            name="numOfFirms"
            value={formData.numOfFirms}
            onChange={handleInputChange}
          ></Input>
          <Text textAlign={"left"}>Enter Number of Regions</Text>
          <Input
            mb={"15px"}
            name="numOfRegions"
            value={formData.numOfRegions}
            onChange={handleInputChange}
          ></Input>
          <Text textAlign={"left"}>Enter Number of Products</Text>
          <Input
            mb={"15px"}
            name="numOfProducts"
            value={formData.numOfProducts}
            onChange={handleInputChange}
          ></Input>
          <Text textAlign={"left"}>Enter Number of Channels on Product</Text>
          <Input
            mb={"15px"}
            name="numOfChannels"
            value={formData.numOfChannels}
            onChange={handleInputChange}
          ></Input>
          <Button onClick={handleSubmit}> Submit </Button>{" "}
          {/* Step 4: Handle form submission */}
        </FormControl>
      </Box>
      {showTbale && (
        <Box mt={"50px"}>
          {/* <Initial numOfProducts={formData.numOfProducts} numOfChannels={formData.numOfChannels}/> */}
          <InitialData
            numOfProducts={formData.numOfProducts}
            numOfChannels={formData.numOfChannels}
            numOfFirms={formData.numOfFirms}
            numOfRegions={formData.numOfRegions}
          />
        </Box>
      )}
    </>
  );
}

export default Cards;
