import React, { useState } from "react";
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Input,
  Button,
  Flex,
} from "@chakra-ui/react";
import "./InitialData.css";

const InitialData = ({
  numOfProducts,
  numOfChannels,
  numOfFirms,
  numOfRegions,
}) => {
  const [selectedValue, setSelectedvalue] = useState(200);
  const [alphaHyperValue,setalphaHyperValue] = useState(5);
  const [alphaMetaValue,setalphaMetaValue] = useState(5);
  const [betaHyperValue,setbetaHyperValue] = useState(5);
  const [betaMetaValue,setbetaMetaValue] = useState(5);

  const productValues = {
    product1: {
      alphaHyper: alphaHyperValue,
      alphaMeta: alphaMetaValue,
      betaHyper: betaHyperValue,
      betaMeta: betaMetaValue,
    },
    product2: {
      alphaHyper: alphaHyperValue,
      alphaMeta: alphaMetaValue,
      betaHyper: betaHyperValue,
      betaMeta: betaMetaValue,
    },
  };

  const firms = numOfFirms;
  const regions = numOfRegions;
  const products = numOfProducts;
  const channels = numOfChannels;
  //const units = 110000;

  const response = {
    "firm_1": {
        "region1": {
            "product1": [
                20000,
                10000
            ],
            "product2": [
                16000,
                11000
            ]
        },
        "region2": {
            "product1": [
                20000,
                20000
            ],
            "product2": [
                11000,
                7000
            ]
        },
        "region3": {
            "product1": [
                35000,
                25000
            ],
            "product2": [
                10000,
                6000
            ]
        }
    },
    "firm_2": {
        "region1": {
            "product1": [
                20000,
                10000
            ],
            "product2": [
                16000,
                11000
            ]
        },
        "region2": {
            "product1": [
                20000,
                20000
            ],
            "product2": [
                11000,
                7000
            ]
        },
        "region3": {
            "product1": [
                35000,
                25000
            ],
            "product2": [
                10000,
                6000
            ]
        }
    }
};
  const result = {};
  const actual = {};
  const alpha = {};
  const percent = {};
  const final = {};

  for (let i = 0; i < firms; i++) {
    const fir = "firm_" + (i + 1);
    // response[fir] = {};
    result[fir] = {};
    actual[fir] = {};
    alpha[fir] = {};
    percent[fir] = {};
    final[fir] = {};

    for (let j = 0; j < regions; j++) {
      const joe = "region" + (j + 1);
      // response[fir][joe] = {};
      result[fir][joe] = {};
      actual[fir][joe] = {};
      alpha[fir][joe] = {};
      percent[fir][joe] = {};
      final[fir][joe] = {};

      for (let k = 0; k < products; k++) {
        const pr = "product" + (k + 1);
        const data = [];
        const ans = [];
        const qtr0 = [];
        const actDemand = [];
        const alphaData = [];
        const percentage = [];
        const finalData = [];
        const ampa = response[fir][joe][pr]

        for (let l = 0; l < channels; l++) {
          // const so = (Math.random() * (2.0 - 0.5) + 0.5).toFixed(2);
          // const var22 = units * (channels / 10);
          // const flag = Math.random() < 0.5;
          // let temp;
          // if (flag) {
          //   temp = var22 - Math.floor((so / 100) * var22);
          // } else {
          //   temp = var22 + Math.floor((so / 100) * var22);
          // }
          //console.log("temp",temp);

          const actDemandValue = Math.floor(
            Math.random() * (selectedValue - -200) + -200
          );
          const randomValue = 2 + Math.random(0) * (0.5).toFixed(2);

          const percentageAmount = Math.floor((randomValue / 100) * ampa[l]);
          console.log(ampa[l]);
          const initial = ampa[l];
          const GDP = percentageAmount + ampa[l];
          const actualDemand = actDemandValue + ampa[l];
          const value = Math.ceil(actualDemand) / 1000;
          const alphaValue = Math.ceil(value) * 1000; //Math.round(0.6*actualDemand +(1-0.6)*temp,-3)

          const absoluteValue = alphaValue - actualDemand;
          const percentageValue = (absoluteValue / actualDemand) * 100;
          const finalvalue =
            1 - Math.abs(alphaValue - actualDemand) / actualDemand;
          const finalResult = Math.floor(finalvalue * 100);

          finalData.push(finalResult);
          ans.push(GDP);
          
          actDemand.push(actualDemand);
          alphaData.push(alphaValue);
          percentage.push(percentageValue);
        }

        //response[fir][joe][pr] = qtr0;
        result[fir][joe][pr] = ans;
        actual[fir][joe][pr] = actDemand;
        alpha[fir][joe][pr] = alphaData;
        percent[fir][joe][pr] = percentage;
        final[fir][joe][pr] = finalData;
      }
    }
  }

  //   result = 1- abs(alpha - actual) / actual
  // print(math.floor(result*100))
  //console.log("Final",final);
//M<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

const productSumsQtr0 = {};

for (const firm in response) {
  const regions = response[firm];
  if (!productSumsQtr0[firm]) {
    productSumsQtr0[firm] = {};
  }

  for (const region in regions) {
    const products = regions[region];
    for (const product in products) {
      if (!productSumsQtr0[firm][product]) {
        productSumsQtr0[firm][product] = 0;
      }

      const productValues = products[product];
      const sum = productValues.reduce((acc, value) => acc + value, 0);
      productSumsQtr0[firm][product] += sum;
    }
  }
}

let sumDataQtr0 = [];
for (const firm in productSumsQtr0) {
  const sum = Object.values(productSumsQtr0[firm]).reduce(
    (acc, value) => acc + value,
    0
  );
  sumDataQtr0.push(sum);
  //console.log(`${firm} = ${sum}`);
}
console.log("sum",sumDataQtr0);
let final_order = 0;
sumDataQtr0.forEach((element)=>{
  final_order += element
 })

 final_order = final_order * 5
 final_order = final_order + final_order * 0.002
 let final_order_QTR0 = final_order;
 //console.log(final_order);



//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



  const productSums = {};

  // Iterate through firms

  for (const firm in alpha) {
    const regions = alpha[firm];
    if (!productSums[firm]) {
      productSums[firm] = {};
    }

    for (const region in regions) {
      const products = regions[region];
      for (const product in products) {
        if (!productSums[firm][product]) {
          productSums[firm][product] = 0;
        }

        const productValues = products[product];
        const sum = productValues.reduce((acc, value) => acc + value, 0);
        productSums[firm][product] += sum;
      }
    }
  }

  let sumData = [];
  for (const firm in productSums) {
    const sum = Object.values(productSums[firm]).reduce(
      (acc, value) => acc + value,
      0
    );
    sumData.push(sum);
    //console.log(`${firm} = ${sum}`);
  }
  let final_order_QTR1 = 0;
  sumData.forEach((element)=>{
    final_order_QTR1 += element
   })
  
   final_order_QTR1 = final_order_QTR1 * 5
   final_order_QTR1 = final_order_QTR1 + final_order_QTR1 * 0.002
   


console.log(final_order_QTR0,'>>>>>>>>>>>>mut>>>>>>>>',final_order_QTR1);
  console.log("Sum of products:", productSums);

  const alphaNeeded = {};

  for (const firm in productSums) {
    alphaNeeded[firm] = {};
    for (const product in productSums[firm]) {
      const dynamicValue = productValues[product].alphaHyper;
      alphaNeeded[firm][product] = productSums[firm][product] * dynamicValue;
    }
  }

  console.log("Alpha Needed:", alphaNeeded);

  const betaNeeded = {};

  for (const firm in productSums) {
    betaNeeded[firm] = {};
    for (const product in productSums[firm]) {
      const dynamicValue = productValues[product].betaHyper;
      betaNeeded[firm][product] = productSums[firm][product] * dynamicValue;
    }
  }

  console.log("Beta Needed:", betaNeeded);

  const forecast = {};

  for (const firm in alpha) {
    const regions = alpha[firm];
    if (!forecast[firm]) {
      forecast[firm] = {};
    }

    for (const region in regions) {
      const products = regions[region];
      for (const product in products) {
        if (!forecast[firm][product]) {
          forecast[firm][product] = 0;
        }

        const productValues = products[product];
        const sum = productValues.reduce((acc, value) => acc + value, 0);
        forecast[firm][product] += sum;
      }
    }
  }
  console.log("forecast", forecast);

  const alphaOrdered = {};

  for (const firm in forecast) {
    alphaOrdered[firm] = {};
    for (const product in forecast[firm]) {
      const dynamicValue = productValues[product].alphaHyper;
      alphaOrdered[firm][product] = forecast[firm][product] * dynamicValue;
    }
  }

  console.log("Alpha Ordered:", alphaOrdered);

  const betaOrdered = {};

  for (const firm in forecast) {
    betaOrdered[firm] = {};
    for (const product in forecast[firm]) {
      const dynamicValue = productValues[product].betaHyper;
      betaOrdered[firm][product] = forecast[firm][product] * dynamicValue;
    }
  }

  console.log("Beta Ordered:", betaOrdered);

  const actualDemandSum = {};

  // Iterate through firms
  for (const firm in actual) {
    const regions = actual[firm];
    if (!actualDemandSum[firm]) {
      actualDemandSum[firm] = {};
    }

    for (const region in regions) {
      const products = regions[region];
      for (const product in products) {
        if (!actualDemandSum[firm][product]) {
          actualDemandSum[firm][product] = 0;
        }

        const productValues = products[product];
        const sum = productValues.reduce((acc, value) => acc + value, 0);
        actualDemandSum[firm][product] += sum;
      }
    }
  }

  //console.log(" Sum of actualDemand",actualDemandSum);
  console.log("response",response);

  const differences = {};

  // Loop through the firms
  for (const firm in productSums) {
    if (!differences[firm]) {
      differences[firm] = {};
    }

    // Iterate through products
    for (const product in productSums[firm]) {
      const productSumValue = productSums[firm][product];
      const actualDemandValue = actualDemandSum[firm][product];
      const diff = productSumValue - actualDemandValue;

      differences[firm][product] = diff;
    }
  }

  const numberOfChannels = channels; // Assuming the number of channels is constant

  const renderChannelHeaders = () => {
    let headers = [];
    for (let i = 1; i <= channels; i++) {
      headers.push(<Th key={`channel-header-${i}`}>Channel {i}</Th>);
    }
    return headers;
  };

  // Function to generate table cells for channel data
  const renderChannelData = (data) => {
    return data.map((value, index) => (
      <Td className="channel-cell" key={`value_${index}`}>
        {value}
      </Td>
    ));
  };

  const renderChannelData2 = (data) => {
    return data.map((value, index) => (
      <Td className="channel-cell" key={`value_${index}`}>
        {value}%
      </Td>
    ));
  };

  return (
    <>
      <div className="table-container">
        <h2>QTR0</h2>
        <h2>Initial Data</h2>
        <Table variant="striped" colorScheme="teal">
          <Thead>
            <Tr>
              <Th>Firm</Th>
              <Th>Region</Th>
              <Th>Product</Th>
              {renderChannelHeaders()}
            </Tr>
          </Thead>
          <Tbody>
            {Object.keys(response).map((firm) =>
              Object.keys(response[firm]).map((region) =>
                Object.keys(response[firm][region]).map(
                  (product, productIndex) => {
                    const rowspan = Object.keys(response[firm][region]).length;
                    return (
                      <Tr key={`${firm}-${region}-${product}`}>
                        {productIndex === 0 && (
                          <Td className="firm-cell" rowSpan={rowspan}>
                            {firm}
                          </Td>
                        )}
                        {productIndex === 0 && (
                          <Td className="region-cell" rowSpan={rowspan}>
                            {region}
                          </Td>
                        )}
                        <Td className="product-cell">{product}</Td>
                        {renderChannelData(response[firm][region][product])}
                      </Tr>
                    );
                  }
                )
              )
            )}
          </Tbody>
        </Table>
      </div>

      <div className="table-container">
        <h2>QTR1</h2>
        <h2>GDP</h2>
        <Table variant="striped" colorScheme="teal">
          <Thead>
            <Tr>
              <Th>Firm</Th>
              <Th>Region</Th>
              <Th>Product</Th>
              {renderChannelHeaders()}
            </Tr>
          </Thead>
          <Tbody>
            {Object.keys(result).map((firm) =>
              Object.keys(result[firm]).map((region) =>
                Object.keys(result[firm][region]).map(
                  (product, productIndex) => {
                    const rowspan = Object.keys(result[firm][region]).length;
                    return (
                      <Tr key={`${firm}-${region}-${product}`}>
                        {productIndex === 0 && (
                          <Td className="firm-cell" rowSpan={rowspan}>
                            {firm}
                          </Td>
                        )}
                        {productIndex === 0 && (
                          <Td className="region-cell" rowSpan={rowspan}>
                            {region}
                          </Td>
                        )}
                        <Td className="product-cell">{product}</Td>
                        {renderChannelData(result[firm][region][product])}
                      </Tr>
                    );
                  }
                )
              )
            )}
          </Tbody>
        </Table>
      </div>

      <div className="table-container">
        <Flex justifyContent={"center"} gap={10}>
          <h2>Actual Demand</h2>
          <Input
            border={"1px solid black"}
            onChange={(e) => setSelectedvalue(e.target.value)}
            w={"10%"}
            type="number"
            value={selectedValue}
            placeholder="Current value is 200"
          />
        </Flex>
        <Table variant="striped" colorScheme="teal">
          <Thead>
            <Tr>
              <Th>Firm</Th>
              <Th>Region</Th>
              <Th>Product</Th>

              {renderChannelHeaders()}
            </Tr>
          </Thead>
          <Tbody>
            {Object.keys(actual).map((firm) =>
              Object.keys(actual[firm]).map((region) =>
                Object.keys(actual[firm][region]).map(
                  (product, productIndex) => {
                    const rowspan = Object.keys(actual[firm][region]).length;
                    return (
                      <Tr key={`${firm}-${region}-${product}`}>
                        {productIndex === 0 && (
                          <Td className="firm-cell" rowSpan={rowspan}>
                            {firm}
                          </Td>
                        )}
                        {productIndex === 0 && (
                          <Td className="region-cell" rowSpan={rowspan}>
                            {region}
                          </Td>
                        )}
                        <Td className="product-cell">{product}</Td>

                        {renderChannelData(actual[firm][region][product])}
                      </Tr>
                    );
                  }
                )
              )
            )}
          </Tbody>
        </Table>
      </div>

      <div className="table-container">
        <h2>Forecast  Alpha</h2>
        <Table variant="striped" colorScheme="teal">
          <Thead>
            <Tr>
              <Th>Firm</Th>
              <Th>Region</Th>
              <Th>Product</Th>
              {renderChannelHeaders()}
            </Tr>
          </Thead>
          <Tbody>
            {Object.keys(alpha).map((firm) =>
              Object.keys(alpha[firm]).map((region) =>
                Object.keys(alpha[firm][region]).map(
                  (product, productIndex) => {
                    const rowspan = Object.keys(alpha[firm][region]).length;
                    return (
                      <Tr key={`${firm}-${region}-${product}`}>
                        {productIndex === 0 && (
                          <Td className="firm-cell" rowSpan={rowspan}>
                            {firm}
                          </Td>
                        )}
                        {productIndex === 0 && (
                          <Td className="region-cell" rowSpan={rowspan}>
                            {region}
                          </Td>
                        )}
                        <Td className="product-cell">{product}</Td>
                        {renderChannelData(alpha[firm][region][product])}
                      </Tr>
                    );
                  }
                )
              )
            )}
          </Tbody>
        </Table>
      </div>

      <div className="table-container">
        <h2>Forecast Accuracy</h2>
        <Table variant="striped" colorScheme="teal">
          <Thead>
            <Tr>
              <Th>Firm</Th>
              <Th>Region</Th>
              <Th>Product</Th>
              {renderChannelHeaders()}
            </Tr>
          </Thead>
          <Tbody>
            {Object.keys(final).map((firm) =>
              Object.keys(final[firm]).map((region) =>
                Object.keys(final[firm][region]).map(
                  (product, productIndex) => {
                    const rowspan = Object.keys(final[firm][region]).length;
                    return (
                      <Tr key={`${firm}-${region}-${product}`}>
                        {productIndex === 0 && (
                          <Td className="firm-cell" rowSpan={rowspan}>
                            {firm}
                          </Td>
                        )}
                        {productIndex === 0 && (
                          <Td className="region-cell" rowSpan={rowspan}>
                            {region}
                          </Td>
                        )}
                        <Td className="product-cell">{product}</Td>
                        {renderChannelData2(final[firm][region][product])}
                      </Tr>
                    );
                  }
                )
              )
            )}
          </Tbody>
        </Table>
      </div>

      <div style={{ marginTop: "50px" }}>
        <h2>Forecast accros region</h2>
        <table>
          <thead>
            <tr>
              <th>Firms</th>
              <th>Product 1</th>
              <th>Product 2</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(productSums).map(([company, products]) => (
              <tr key={company}>
                <td>{company}</td>
                <td>{products.product1}</td>
                <td>{products.product2}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: "50px" }}>
        <h6>Sum of Actual Demand</h6>
        <table>
          <thead>
            <tr>
              <th>Firms</th>
              <th>Product 1</th>
              <th>Product 2</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(actualDemandSum).map(([company, products]) => (
              <tr key={company}>
                <td>{company}</td>
                <td>{products.product1}</td>
                <td>{products.product2}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: "50px" }}>
        <h6>EndInventory(difference)</h6>
        <table>
          <thead>
            <tr>
              <th>Firms</th>
              <th>Product 1</th>
              <th>Product 2</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(differences).map(([company, products]) => (
              <tr key={company}>
                <td>{company}</td>
                <td>{products.product1}</td>
                <td>{products.product2}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: "50px" }}>
        <h2>total units(products) Per Firm</h2>
        <table>
          <thead>
            <tr>
              <th>Firms</th>
              <th>Value</th>
            </tr>
          </thead>
          <tbody>
            {sumData.map((value, index) => (
              <tr key={index}>
                <td>{`firm${index + 1}`}</td>
                <td>{value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: "50px" }}>
        <h2>Explode to BOM</h2>
        <table>
          <tbody>
            <tr>
              <th>Raw/SAC Needs</th>
              <th>Product 1</th>
              <th>Product 2 </th>
            </tr>
            <tr>
              <td>Alpha (kg/unit)</td>
              <td>
                <Flex justifyContent={"center"} gap={5}>
                  {/* {productValues.product1.alphaHyper} */}
                  <Input w={"12%"} value={alphaHyperValue} onChange={(e)=>setalphaHyperValue(e.target.value)}/>
                </Flex>
              </td>
              <td>
                <Flex justifyContent={"center"} gap={5}>
                  {/* {productValues.product1.alphaMeta} */}
                  <Input w={"12%"} value={alphaMetaValue} onChange={(e)=>setalphaMetaValue(e.target.value)}/>
                </Flex>
              </td>
            </tr>
            <tr>
              <td>Beta (kg/unit)</td>
              <td contentEditable="true">
                <Flex justifyContent={"center"} gap={5}>
                  {/* {productValues.product2.betaHyper} */}
                  <Input w={"12%"} value={betaHyperValue} onChange={(e)=>setbetaHyperValue(e.target.value)} />
                </Flex>
              </td>
              <td contentEditable="true">
                <Flex justifyContent={"center"} gap={5}>
                  {/* {productValues.product2.betaMeta} */}
                  <Input w={"12%"} value={betaMetaValue} onChange={(e)=>setbetaMetaValue(e.target.value)}/>
                </Flex>
              </td>
            </tr>
            <tr>
              <td>Epsilon (#/unit)</td>
              <td contentEditable="true">1</td>
              <td contentEditable="true">1</td>
            </tr>
            <tr>
              <td>Gamma (#/unit)</td>
              <td contentEditable="true">1</td>
              <td contentEditable="true">0</td>
            </tr>
            <tr>
              <td>Delta (#/unit)</td>
              <td contentEditable="true">0</td>
              <td contentEditable="true">1</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: "50px" }}>
        <h2>Raw needed</h2>
        <table>
          <thead>
            <tr>
              <th>Firm</th>
              <th>Production</th>
              <th> Production Alpha Needed</th>
              <th>Production Beta Needed</th>
              <th>Forecast</th>
              <th>Forecast Alpha Ordered</th>
              <th>Forecast Beta Ordered</th>
            </tr>
          </thead>
          <tbody>
            {Object.keys(productSums).map((firm) => (
              <>
                <tr key={firm}>
                  <td>{firm}</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>Product1</td>

                  <td>{productSums[firm]["product1"]}</td>
                  <td>{alphaNeeded[firm]["product1"]}</td>
                  <td>{betaNeeded[firm]["product1"]}</td>
                  <td>{forecast[firm]["product1"]}</td>
                  <td>{alphaOrdered[firm]["product1"]}</td>
                  <td>{betaOrdered[firm]["product1"]}</td>
                </tr>
                <tr key={`${firm}-product2`}>
                  <td>Product2</td>
                  <td>{productSums[firm]["product2"]}</td>
                  <td>{alphaNeeded[firm]["product2"]}</td>
                  <td>{betaNeeded[firm]["product2"]}</td>
                  <td>{forecast[firm]["product2"]}</td>
                  <td>{alphaOrdered[firm]["product2"]}</td>
                  <td>{betaOrdered[firm]["product2"]}</td>
                </tr>
              </>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default InitialData;
